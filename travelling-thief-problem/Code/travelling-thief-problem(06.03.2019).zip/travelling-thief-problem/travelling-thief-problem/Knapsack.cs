﻿using System.Collections.Generic;

namespace travelling_thief_problem
{
    public class Knapsack
    {
        double capacity;
        List<Item> itemsIn;
    }
}