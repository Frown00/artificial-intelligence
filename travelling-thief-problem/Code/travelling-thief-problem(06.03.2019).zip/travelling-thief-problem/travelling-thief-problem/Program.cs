﻿using System;
using System.Collections.Generic;
using System.IO;

namespace travelling_thief_problem
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> setup = ReadProblemSetup("easy_2");

            TravellingThiefProblem travellingThiefProblem = new TravellingThiefProblem(setup);

            Console.ReadKey();
        }

        static List<string> ReadProblemSetup(string relativePath)
        {
            string line = "";
            List<string> setup = new List<string>();
            
            try
            {
                StreamReader setupFile = new StreamReader($"student\\{relativePath}.ttp");

                while ((line = setupFile.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
                setupFile.Close();
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex);
            }

            return setup;
        }
    }

    
}
