﻿namespace travelling_thief_problem
{
    internal class Item
    {
    }
}