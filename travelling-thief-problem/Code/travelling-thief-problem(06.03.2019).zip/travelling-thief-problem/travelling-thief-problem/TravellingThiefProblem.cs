﻿using System;
using System.Collections.Generic;
using System.Text;

namespace travelling_thief_problem
{
    class TravellingThiefProblem
    {
        string problemName;
        string knapsackDataType;
        Thief thief;
        int dimension;
        int itemsNum;
        double rentingRatio;
        string edgeWeigthType;

        List<Item> items;
        List<City> cities;

        public TravellingThiefProblem(List<string> problemSetup)
        {
            MapToObject(problemSetup);   
        }

        private void MapToObject(List<string> problemSetup)
        {
            
            this.problemName = problemSetup[0].Split(" ")[1];

            throw new NotImplementedException();
        }
    }
}
